// ─────────────────────────────────────────────────────────────────────────────
// src/services/parseResults.js
//
// The BE returns raw soil_data, weather_data, predictions as JSON blobs.
// These helpers pull out the display-friendly numbers for the UI.
// ─────────────────────────────────────────────────────────────────────────────

// Capitalise each word: "rice" → "Rice", "kidney_beans" → "Kidney Beans"
export function formatCropName(name = "") {
  return name.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
}

// Convert ML probability (0–1) to a 0–100 score and a risk level
export function deriveScore(probability = 0) {
  const cropScore = Math.round(probability * 100);
  const riskLevel = cropScore >= 70 ? "Low" : cropScore >= 45 ? "Medium" : "High";
  return { cropScore, riskLevel };
}

// Pull averaged weather values out of the Open-Meteo response shape
// weather_data = { daily: { temperature_2m_mean[], precipitation_sum[] },
//                  hourly: { relative_humidity_2m[] } }
export function parseWeather(weatherData = {}) {
  try {
    const avg = arr =>
      arr?.length ? arr.reduce((s, v) => s + (v ?? 0), 0) / arr.length : 0;
    return {
      temperature: +avg(weatherData?.daily?.temperature_2m_mean).toFixed(1),
      rainfall:    +avg(weatherData?.daily?.precipitation_sum).toFixed(1),
      humidity:    +avg(weatherData?.hourly?.relative_humidity_2m).toFixed(1),
    };
  } catch {
    return { temperature: 25, rainfall: 103, humidity: 71 };
  }
}

// Pull nitrogen (kg/ha) and pH from the SoilGrids response shape
export function parseSoil(soilData = {}) {
  try {
    const layers   = soilData?.properties?.layers ?? [];
    const nLayer   = layers.find(l => l.name === "nitrogen");
    const phLayer  = layers.find(l => l.name === "phh2o");

    const avg = (layer) =>
      layer.depths.reduce((s, d) => s + (d.values?.mean ?? 0), 0) /
      layer.depths.length /
      layer.unit_measure.d_factor;

    const nitrogenGkg = avg(nLayer);
    const ph          = +avg(phLayer).toFixed(1);
    // g/kg → kg/ha: bulk_density(1.3) × depth(30) × 0.1
    const nitrogenKgHa = +(nitrogenGkg * 1.3 * 30 * 0.1).toFixed(1);

    return { nitrogen: nitrogenKgHa, ph };
  } catch {
    return { nitrogen: 51, ph: 6.5 };
  }
}

// Parse top3 predictions { crop: probability } → sorted array for the bar chart
export function parseTop3(top3 = {}) {
  return Object.entries(top3)
    .sort((a, b) => b[1] - a[1])
    .map(([crop, prob]) => ({
      name: formatCropName(crop),
      prob: Math.round(prob * 100),
    }));
}

// Master parser — takes a full Analysis object from /api/predict or /api/history
export function parseAnalysis(analysis) {
  const predictions = analysis.predictions ?? {};
  const { cropScore, riskLevel } = deriveScore(predictions.probability ?? 0);
  const weather  = parseWeather(analysis.weather_data);
  const soil     = parseSoil(analysis.soil_data);
  const top3     = parseTop3(predictions.top3 ?? {});

  return {
    id:              analysis.id,
    date:            analysis.created_at
                       ? new Date(analysis.created_at).toISOString().split("T")[0]
                       : "—",
    latitude:        analysis.latitude,
    longitude:       analysis.longitude,
    locationName:    analysis.location_name || `${analysis.latitude?.toFixed(4)}, ${analysis.longitude?.toFixed(4)}`,
    cropScore,
    riskLevel,
    predictionClass: formatCropName(predictions.prediction_class ?? ""),
    probability:     Math.round((predictions.probability ?? 0) * 100),
    top3,
    aiResponse:      analysis.ai_response ?? "",
    // weather
    temperature:     weather.temperature,
    rainfall:        weather.rainfall,
    humidity:        weather.humidity,
    // soil
    nitrogen:        soil.nitrogen,
    ph:              soil.ph,
  };
}
